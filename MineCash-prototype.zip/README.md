# MineCash — prototype

A mobile-responsive React/Vite prototype for a mining-rewards app focused on Nigerian users.

## Current features
- Mining session timer with simulated demo rewards
- Demo wallet balance and transaction history
- Withdrawal form previews for Nigerian bank transfer, airtime, mobile data, and crypto
- Referral screen placeholder
- Responsive mobile layout

## Important status
This is a **front-end prototype only**. The displayed ₦ balances are simulated demo credits, not real money. No payment provider, real mining/revenue source, authentication, database, or payout service is connected. The withdrawal form intentionally does not send money.

## Run locally
Requires Node.js 18+.

```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Production roadmap
1. Add secure registration/login and session management.
2. Add a backend API and PostgreSQL database.
3. Implement a server-side, auditable ledger. Never let the browser decide a user's cash balance.
4. Define and verify a real source of rewards/revenue before crediting withdrawable funds.
5. Add fraud controls, rate limits, withdrawal limits, and admin review.
6. Integrate licensed/approved payout providers for bank transfer, airtime/data, and supported crypto routes.
7. Add KYC/AML, privacy policy, terms, customer support, and compliance review appropriate to the operating jurisdictions.
8. Run security tests and payout reconciliation before launch.

## Suggested next stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: PostgreSQL
- Authentication: secure, server-managed sessions or a vetted identity provider
- Payments: provider APIs, with secrets held only on the server
