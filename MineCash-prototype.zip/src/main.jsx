import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Pickaxe, Wallet, History, Users, CircleHelp, Zap, ShieldCheck, ArrowDownToLine, Play, Pause, Smartphone, Database, Bitcoin, Building2, ChevronRight, Copy, Menu } from 'lucide-react';
import './style.css';

const money = n => '₦' + Number(n).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
const initialTx = [
  {id:'MC-1003', title:'Daily mining reward', date:'Today · 09:20', amount:125, status:'Demo'},
  {id:'MC-1002', title:'Mining session reward', date:'Yesterday · 18:10', amount:80, status:'Demo'},
];
function App() {
  const [tab,setTab] = useState('Mine');
  const [mining,setMining] = useState(false);
  const [seconds,setSeconds] = useState(0);
  const [balance,setBalance] = useState(205);
  const [transactions,setTransactions] = useState(initialTx);
  const [amount,setAmount] = useState('100');
  const [method,setMethod] = useState('Bank transfer');
  const [details,setDetails] = useState('');
  const [notice,setNotice] = useState('');
  const [menu,setMenu] = useState(false);

  useEffect(()=>{
    if(!mining) return;
    const id = setInterval(()=>setSeconds(s=>s+1),1000);
    return ()=>clearInterval(id);
  },[mining]);

  const start = () => {
    setMining(v=>!v);
    setNotice(mining ? 'Mining session paused.' : 'Demo mining session started.');
  };
  const claim = () => {
    if(seconds < 10) { setNotice('Run the demo session for at least 10 seconds before claiming.'); return; }
    const reward = Math.min(25, Math.floor(seconds/10)*5);
    setBalance(v=>v+reward);
    setTransactions(t=>[{id:'MC-'+Date.now().toString().slice(-6),title:'Mining session reward',date:'Just now',amount:reward,status:'Demo'},...t]);
    setSeconds(0); setMining(false);
    setNotice(`${money(reward)} demo reward added to your demo balance.`);
  };
  const requestWithdrawal = e => {
    e.preventDefault();
    if(!details.trim()) {setNotice('Enter the destination details to preview your withdrawal request.');return;}
    if(Number(amount)<=0 || Number(amount)>balance) {setNotice('Enter an amount above ₦0 and no greater than your displayed balance.');return;}
    setNotice('Preview only: no withdrawal was sent and no real money was transferred. Payment processing is not connected yet.');
  };
  const nav = [
    ['Mine',Pickaxe],['Wallet',Wallet],['Withdraw',ArrowDownToLine],['History',History],['Referrals',Users]
  ];
  const navTo = t => {setTab(t);setMenu(false);setNotice('');};
  const time = `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
  return <div className="app-shell">
    <aside className={`sidebar ${menu?'open':''}`}>
      <div className="brand"><div className="brand-icon"><Pickaxe size={23}/></div><span>mine<span className="brand-light">cash</span></span></div>
      <div className="profile"><div className="avatar">M</div><div><b>MineCash Member</b><small>Demo account</small></div></div>
      <div className="nav-label">WORKSPACE</div>
      {nav.map(([name,Icon])=><button key={name} onClick={()=>navTo(name)} className={`nav-item ${tab===name?'active':''}`}><Icon size={19}/><span>{name}</span>{name==='Wallet'&&<span className="nav-dot"/>}</button>)}
      <div className="side-bottom"><div className="help-card"><CircleHelp size={19}/><b>Need help?</b><p>Support options will be available at launch.</p></div><div className="side-footer"><ShieldCheck size={15}/> Secure rewards, transparent rules</div></div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMenu(!menu)}><Menu/></button><div><span className="eyebrow">YOUR REWARDS SPACE</span><h1>{tab==='Mine'?'Mining dashboard':tab}</h1></div><div className="top-actions"><span className="demo-pill"><span/> DEMO MODE</span><div className="avatar small">M</div></div></header>
      <div className="content">
        {notice&&<div className="notice"><span>{notice}</span><button onClick={()=>setNotice('')}>×</button></div>}
        {tab==='Mine'&&<>
          <section className="welcome-row"><div><h2>Make every session count.</h2><p>Start a session, track your demo rewards, and explore withdrawal options.</p></div><div className="live-tag"><span/> SYSTEM PREVIEW</div></section>
          <section className="balance-grid">
            <div className="balance-card"><div className="card-top"><span>Available demo balance</span><Wallet size={19}/></div><div className="balance">{money(balance)}</div><div className="balance-note"><span className="up">↗</span> Prototype credits · not cash</div><div className="card-bottom"><span>MineCash wallet</span><span className="tiny-logo">MC</span></div></div>
            <div className="stat-card"><div className="stat-icon"><Zap size={20}/></div><span>Total demo earned</span><strong>{money(balance)}</strong><small>Since this prototype session</small><div className="stat-line"><i/></div></div>
            <div className="stat-card"><div className="stat-icon"><History size={20}/></div><span>Mining time</span><strong>{time}</strong><small>{mining?'Session currently running':'Ready when you are'}</small><div className="stat-line"><i style={{width:`${Math.min(100,seconds/3)}%`}}/></div></div>
          </section>
          <section className="mining-layout">
            <div className="panel mining-panel"><div className="panel-heading"><div><span className="eyebrow">MINING ENGINE</span><h3>Your mining session</h3></div><span className={`status ${mining?'running':''}`}><i/>{mining?'Running':'Idle'}</span></div>
              <div className={`orb ${mining?'pulse':''}`}><div className="orb-inner"><Pickaxe size={43}/><b>{time}</b><small>SESSION TIME</small></div></div>
              <p className="center muted">{mining?'Your demo session is ticking.':'Start a session to test the mining flow.'}</p>
              <div className="mining-actions"><button className="primary-btn" onClick={start}>{mining?<Pause size={18}/>:<Play size={18}/>} {mining?'Pause session':'Start mining'}</button><button className="secondary-btn" onClick={claim}>Claim demo reward</button></div>
              <div className="info-strip"><ShieldCheck size={17}/><span>Demo rewards are simulated. Real payouts require a funded, verified backend.</span></div>
            </div>
            <div className="panel quick-panel"><div className="panel-heading"><div><span className="eyebrow">QUICK ACCESS</span><h3>Use your rewards</h3></div></div><p className="muted">Withdrawal methods planned for MineCash.</p>
              <button className="method-row" onClick={()=>navTo('Withdraw')}><span className="method-icon"><Building2/></span><span><b>Nigerian bank</b><small>Bank account transfer</small></span><ChevronRight/></button>
              <button className="method-row" onClick={()=>navTo('Withdraw')}><span className="method-icon"><Smartphone/></span><span><b>Airtime & data</b><small>MTN · Airtel · Glo · 9mobile</small></span><ChevronRight/></button>
              <button className="method-row" onClick={()=>navTo('Withdraw')}><span className="method-icon"><Bitcoin/></span><span><b>Crypto wallet</b><small>Crypto payout interface planned</small></span><ChevronRight/></button>
              <div className="availability"><span className="availability-dot"/>Payment providers not connected yet</div>
            </div>
          </section>
          <section className="panel activity-panel"><div className="panel-heading"><div><span className="eyebrow">LATEST ACTIVITY</span><h3>Recent transactions</h3></div><button className="text-btn" onClick={()=>navTo('History')}>View all <ChevronRight size={16}/></button></div><Transactions items={transactions.slice(0,3)}/></section>
        </>}
        {tab==='Wallet'&&<section className="panel page-panel"><span className="eyebrow">MINECASH WALLET</span><h2>{money(balance)}</h2><p className="muted">Displayed amount is demo credit and has no cash value.</p><div className="wallet-actions"><button className="primary-btn" onClick={()=>navTo('Mine')}>Continue mining</button><button className="secondary-btn" onClick={()=>navTo('Withdraw')}>Explore withdrawals</button></div><Transactions items={transactions}/></section>}
        {tab==='Withdraw'&&<section className="panel page-panel"><span className="eyebrow">PAYOUT CENTRE</span><h2>Withdraw rewards</h2><p className="muted">Choose a payout route. This form is a preview; live payment rails are not connected.</p><div className="withdraw-warning"><ShieldCheck size={20}/><div><b>Demo mode</b><p>Do not enter passwords, PINs, BVNs, seed phrases, or other sensitive credentials. No money will move from this prototype.</p></div></div><form onSubmit={requestWithdrawal} className="withdraw-form"><label>Withdrawal method<select value={method} onChange={e=>setMethod(e.target.value)}><option>Bank transfer</option><option>Airtime</option><option>Mobile data</option><option>Crypto wallet</option></select></label><label>Amount (₦)<input inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="100"/></label><label>{method==='Bank transfer'?'Bank name and account number (test details only)':method==='Airtime'?'Network and phone number (test details only)':method==='Mobile data'?'Network and phone number (test details only)':'Wallet address (test address only)'}<input value={details} onChange={e=>setDetails(e.target.value)} placeholder="Enter non-sensitive test details"/></label><button className="primary-btn" type="submit"><ArrowDownToLine size={18}/> Preview withdrawal</button></form><p className="fineprint">Live withdrawals will only be enabled after identity/security controls, a funded rewards source, payment-provider integration, and server-side ledger validation are in place.</p></section>}
        {tab==='History'&&<section className="panel page-panel"><span className="eyebrow">ACCOUNT RECORDS</span><h2>Transaction history</h2><p className="muted">All entries below are simulated prototype records.</p><Transactions items={transactions}/></section>}
        {tab==='Referrals'&&<section className="panel page-panel"><span className="eyebrow">GROW TOGETHER</span><h2>Invite friends</h2><p className="muted">Referral rewards are not active yet. A real referral programme needs fraud prevention and clear reward rules.</p><div className="referral-box"><Users size={28}/><h3>Your referral link</h3><div className="fake-link">minecash.app/ref/demo-user <Copy size={16}/></div><button className="secondary-btn" onClick={()=>setNotice('Referral links will activate when user accounts and the referral service are connected.')}>Preview referral feature</button></div></section>}
        <footer className="footer"><span>© 2026 MineCash</span><span>Built for transparent rewards</span><span className="footer-demo"><i/> Prototype · no real-money payouts</span></footer>
      </div>
    </main>
  </div>
}
function Transactions({items}) {
 return <div className="transactions">{items.map((tx,i)=><div className="tx-row" key={tx.id}><div className="tx-icon"><Database size={18}/></div><div className="tx-main"><b>{tx.title}</b><small>{tx.date} · {tx.id}</small></div><div className="tx-amount"><b>+{money(tx.amount)}</b><small>{tx.status}</small></div></div>)}</div>
}
createRoot(document.getElementById('root')).render(<App/>);